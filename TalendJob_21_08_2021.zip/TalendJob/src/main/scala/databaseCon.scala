import java.util.Properties

import org.apache.log4j.{Level, Logger}
import org.apache.spark.sql.SparkSession

object databaseCon {
  def main(args: Array[String]): Unit = {
    // Create a SparkSession session.
    val spark = SparkSession.builder.master("local[2]").appName("appName").getOrCreate();

    Logger.getLogger("org").setLevel(Level.ERROR)
    val url = "jdbc:postgresql://localhost:5432/hr_data"
    val connectionProperties = new Properties()
    connectionProperties.setProperty("Driver", "org.postgresql.Driver")
    connectionProperties.setProperty("user", "postgres")
    connectionProperties.setProperty("password", "admin")
    val query1 = "(SELECT * FROM cars) as q1"
    val query1df = spark.read.jdbc(url, query1, connectionProperties)
    query1df.show()
    spark.close()
  }
}
